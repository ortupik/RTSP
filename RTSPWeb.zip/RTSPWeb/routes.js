const express = require('express');
const fs = require("fs");
const ws = require('ws');
const http = require('http');
const spawn = require('child_process').spawn;

var host = "http://localhost";
//var host = "https://stream-app-test.herokuapp.com";
var stream = null;

function initalizeWS(WebSocket){

		var STREAM_SECRET = "lala",
			STREAM_PORT = 8081,
			WEBSOCKET_PORT = 8082,
			RECORD_STREAM = false;

		// Websocket Server
		var socketServer = new WebSocket.Server({port:WEBSOCKET_PORT, perMessageDeflate: false});
		socketServer.connectionCount = 0;
		socketServer.on('connection', function(socket, upgradeReq) {
			socketServer.connectionCount++;
			console.log(
				'New WebSocket Connection: ', 
				(upgradeReq || socket.upgradeReq).socket.remoteAddress,
				(upgradeReq || socket.upgradeReq).headers['user-agent'],
				'('+socketServer.connectionCount+' total)'
			);
			socket.on('close', function(code, message){
				socketServer.connectionCount--;
				console.log(
					'Disconnected WebSocket ('+socketServer.connectionCount+' total)'
				);
			});
		});
		socketServer.broadcast = function(data) {
			socketServer.clients.forEach(function each(client) {
				if (client.readyState === WebSocket.OPEN) {
					client.send(data);
				}
			});
		};

		// HTTP Server to accept incomming MPEG-TS Stream from ffmpeg
		var streamServer = http.createServer( function(request, response) {

			var params = request.url.substr(1).split('/');

			if (params[0] !== STREAM_SECRET) {
				console.log(
					'Failed Stream Connection: '+ request.socket.remoteAddress + ':' +
					request.socket.remotePort + ' - wrong secret.'
				);
				response.end();
			}

			response.connection.setTimeout(0);

			console.log(
				'Stream Connected: ' + 
				request.socket.remoteAddress + ':' +
				request.socket.remotePort
			);
			request.on('data', function(data){
				socketServer.broadcast(data);
				if (request.socket.recording) {
					request.socket.recording.write(data);
				}
			});
			request.on('end',function(){
				console.log('close');
				if (request.socket.recording) {
					request.socket.recording.close();
				}
			});

			// Record the stream to a local file?
			if (RECORD_STREAM) {
				var path = './saved_videos/' + Date.now() + '.ts';
				request.socket.recording = fs.createWriteStream(path);
			}
		}).listen(STREAM_PORT)

		console.log('Listening for incomming MPEG-TS Stream on http://:'+STREAM_PORT+'/<secret>');
		console.log('Awaiting WebSocket connections on ws://:'+WEBSOCKET_PORT+'/');

};

module.exports = function(app,port){
		
	app.get('/', (req, res) => {
		res.render("stream");
	});

	app.get("/show_saved_videos", (req, res) => {
       var path = "./public/saved_videos";
 
		fs.readdir(path, function(err, items) {
		    console.log(items);
		    res.render("play_videos",{videos:items});		   
		});
	});

	app.get('/stream', (req, res) => {

       var _url = req.query.url;

       var ffmpeg = spawn('ffmpeg', ['-i',_url, "-f" ,"mpegts" ,"-codec:v" ,"mpeg1video" , "-b:v" ,"1000k"  ,host+":8081/lala"]);
 
		ffmpeg.stderr.on('data', function (data) {
		    console.log(data.toString());
		    //res.write(data)
		});

		ffmpeg.stderr.on('end', function () {  
		    console.log('file has been saved succesfully');
		  //  res.json({message:'file has been saved succesfully'})
		    res.end();
		});

		ffmpeg.stderr.on('exit', function () {
		    console.log('child process exited');
		     //res.json({message:'child process exited'})
		     res.end();
		});

		ffmpeg.stderr.on('close', function() {
		    console.log('...closing time! bye');
		   // res.json({message:'...closing time! by'})
		    res.end();
		});

		res.render("stream",{url:_url});

	});

	
	//http://localhost:8000/test_stream?url=rtsp://184.72.239.149/vod/mp4:BigBuckBunny_175k.mov

	app.get("/save_stream", (req, res) => { 

       var _url = req.query.url;

		var ffmpeg = spawn('ffmpeg', ['-i',_url, "-threads", "3", "-t", "50", "-vcodec","copy", "-f", "segment", "-segment_time", "10", "./public/saved_videos/video%04d.mp4" ]);

		ffmpeg.stderr.on('data', function (data) {
		    console.log(data.toString());
		    //res.write(data)
		});

		ffmpeg.stderr.on('end', function () {  
		    console.log('file has been saved succesfully');
		  //  res.json({message:'file has been saved succesfully'})
		    res.end();
		});

		ffmpeg.stderr.on('exit', function () {
		    console.log('child process exited');
		     //res.json({message:'child process exited'})
		     res.end();
		});

		ffmpeg.stderr.on('close', function() {
		    console.log('...closing time! bye');
		   // res.json({message:'...closing time! by'})
		    res.end();
		});

	});

	app.get('/stop_stream', (req, res) => {
		if(stream != null){
			stream.stop();
			res.send({success:1,message:"Stream Stopped !!"});
		}
	});

     initalizeWS(ws,app);
	
		
};