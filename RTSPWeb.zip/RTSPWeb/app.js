var express = require('express');
app = express();

var address =  process.env.OPENSHIFT_NODEJS_IP || "http://127.0.0.1:8000"; // Listening to localhost if you run locally
var port = process.env.PORT || 8000;

app.listen(port);//emit address if persist

require('./config')(app);
require('./routes')(app,port);


console.log('RTSP is running on http://host:' + port +" address "+address);
